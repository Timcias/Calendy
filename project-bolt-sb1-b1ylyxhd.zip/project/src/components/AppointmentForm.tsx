import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import useAppointmentStore from '../store/appointmentStore';
import useClientStore from '../store/clientStore';
import useAuthStore from '../store/authStore';
import { X } from 'lucide-react';

interface AppointmentFormProps {
  onClose: () => void;
  editId?: string;
}

const AppointmentForm = ({ onClose, editId }: AppointmentFormProps) => {
  const { appointments, addAppointment, updateAppointment } = useAppointmentStore();
  const { clients, addClient } = useClientStore();
  const { user } = useAuthStore();
  const [error, setError] = useState<string | null>(null);
  const [isNewClient, setIsNewClient] = useState(false);
  
  const appointment = editId 
    ? appointments.find(a => a.id === editId) 
    : null;
  
  const { register, handleSubmit, formState: { errors }, setValue } = useForm({
    defaultValues: appointment 
      ? {
          clientId: appointment.clientId,
          clientName: appointment.clientName,
          clientPhone: appointment.clientPhone,
          service: appointment.service,
          date: format(new Date(appointment.date), "yyyy-MM-dd'T'HH:mm"),
        }
      : {
          clientId: '',
          clientName: '',
          clientPhone: '',
          service: '',
          date: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
        }
  });

  const onSubmit = (data: any) => {
    if (!user) return;
    
    let clientId = data.clientId;
    
    if (isNewClient || !clientId) {
      clientId = addClient({
        name: data.clientName,
        phone: data.clientPhone,
        interval: 60,
      });
    }
    
    const appointmentData = {
      clientId,
      clientName: data.clientName,
      clientPhone: data.clientPhone,
      service: data.service,
      date: new Date(data.date).toISOString(),
      status: 'scheduled' as const,
      userId: user.id,
    };
    
    if (editId) {
      updateAppointment(editId, appointmentData);
      onClose();
    } else {
      const result = addAppointment(appointmentData);
      if (result) {
        onClose();
      } else {
        setError('Il y a un conflit horaire avec un autre rendez-vous.');
      }
    }
  };
  
  const handleClientChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const clientId = e.target.value;
    if (clientId === 'new') {
      setIsNewClient(true);
      setValue('clientName', '');
      setValue('clientPhone', '');
    } else {
      setIsNewClient(false);
      const client = clients.find(c => c.id === clientId);
      if (client) {
        setValue('clientName', client.name);
        setValue('clientPhone', client.phone);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-gray-800">
            {editId ? 'Modifier le Rendez-vous' : 'Nouveau Rendez-vous'}
          </h2>
          <button 
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        {error && (
          <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
            {error}
          </div>
        )}
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Client
            </label>
            <select
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              {...register('clientId')}
              onChange={handleClientChange}
              disabled={!!editId}
            >
              <option value="">Sélectionnez un client ou créez-en un nouveau</option>
              <option value="new">+ Ajouter un nouveau client</option>
              {clients.map(client => (
                <option key={client.id} value={client.id}>
                  {client.name} ({client.phone})
                </option>
              ))}
            </select>
          </div>
          
          {(isNewClient || !register('clientId').value) && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nom du client
                </label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  {...register('clientName', { required: 'Le nom du client est requis' })}
                />
                {errors.clientName && (
                  <p className="mt-1 text-sm text-red-600">{errors.clientName.message as string}</p>
                )}
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Numéro de téléphone
                </label>
                <input
                  type="tel"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  {...register('clientPhone', { required: 'Le numéro de téléphone est requis' })}
                />
                {errors.clientPhone && (
                  <p className="mt-1 text-sm text-red-600">{errors.clientPhone.message as string}</p>
                )}
              </div>
            </>
          )}
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Service
            </label>
            <input
              type="text"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              {...register('service', { required: 'Le service est requis' })}
            />
            {errors.service && (
              <p className="mt-1 text-sm text-red-600">{errors.service.message as string}</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Date et heure
            </label>
            <input
              type="datetime-local"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              {...register('date', { required: 'La date et l\'heure sont requises' })}
            />
            {errors.date && (
              <p className="mt-1 text-sm text-red-600">{errors.date.message as string}</p>
            )}
          </div>
          
          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 rounded-md text-sm font-medium text-white hover:bg-indigo-700"
            >
              {editId ? 'Mettre à jour' : 'Créer'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AppointmentForm;