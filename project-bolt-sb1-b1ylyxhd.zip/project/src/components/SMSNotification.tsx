import { useEffect, useState } from 'react';
import { Bell, BellOff } from 'lucide-react';

const SMSNotification = () => {
  const [enabled, setEnabled] = useState(true);
  const [message, setMessage] = useState<string | null>(null);
  
  useEffect(() => {
    if (enabled) {
      const timer = setTimeout(() => {
        setMessage('Les notifications SMS sont actives. Les rappels seront envoyés automatiquement.');
        
        const clearTimer = setTimeout(() => {
          setMessage(null);
        }, 5000);
        
        return () => clearTimeout(clearTimer);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, [enabled]);
  
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between bg-white rounded-lg shadow-md p-4">
        <div className="flex items-center">
          {enabled ? (
            <Bell className="h-5 w-5 text-indigo-600 mr-2" />
          ) : (
            <BellOff className="h-5 w-5 text-gray-400 mr-2" />
          )}
          <div>
            <h3 className="font-medium text-gray-900">Notifications SMS</h3>
            <p className="text-sm text-gray-500">
              {enabled 
                ? 'Les clients recevront des rappels SMS 1 heure avant et la veille de leur rendez-vous.' 
                : 'Les notifications SMS sont actuellement désactivées.'}
            </p>
          </div>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input 
            type="checkbox" 
            className="sr-only peer" 
            checked={enabled}
            onChange={() => setEnabled(!enabled)}
          />
          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-indigo-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
        </label>
      </div>
      
      {message && (
        <div className="mt-2 p-2 bg-green-100 text-green-800 rounded-md text-sm">
          {message}
        </div>
      )}
    </div>
  );
};

export default SMSNotification;