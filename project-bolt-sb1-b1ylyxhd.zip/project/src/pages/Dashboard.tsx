import { useState } from 'react';
import AppointmentList from '../components/AppointmentList';
import SMSNotification from '../components/SMSNotification';
import { Calendar, Clock, Users } from 'lucide-react';
import useAppointmentStore from '../store/appointmentStore';
import useAuthStore from '../store/authStore';
import { format, parseISO, isToday, isFuture } from 'date-fns';
import { fr } from 'date-fns/locale';

const Dashboard = () => {
  const { appointments } = useAppointmentStore();
  const { user } = useAuthStore();
  const [activeTab, setActiveTab] = useState('upcoming');
  
  if (!user) return null;
  
  const userAppointments = appointments.filter(a => a.userId === user.id);
  
  const upcomingAppointments = userAppointments.filter(
    a => a.status === 'scheduled' && isFuture(parseISO(a.date))
  );
  
  const todayAppointments = upcomingAppointments.filter(
    a => isToday(parseISO(a.date))
  );
  
  const getNextAppointment = () => {
    if (upcomingAppointments.length === 0) return null;
    
    return upcomingAppointments.reduce((closest, current) => {
      if (!closest) return current;
      
      const closestDate = parseISO(closest.date);
      const currentDate = parseISO(current.date);
      
      return currentDate < closestDate ? current : closest;
    }, null as any);
  };
  
  const nextAppointment = getNextAppointment();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-6">Bon retour !</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-indigo-100 text-indigo-600">
              <Calendar className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700">Aujourd'hui</h2>
              <p className="text-3xl font-bold text-gray-900">{todayAppointments.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-purple-100 text-purple-600">
              <Clock className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700">À venir</h2>
              <p className="text-3xl font-bold text-gray-900">{upcomingAppointments.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-full bg-green-100 text-green-600">
              <Users className="h-6 w-6" />
            </div>
            <div className="ml-4">
              <h2 className="text-lg font-semibold text-gray-700">Total</h2>
              <p className="text-3xl font-bold text-gray-900">{userAppointments.length}</p>
            </div>
          </div>
        </div>
      </div>
      
      {nextAppointment && (
        <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg shadow-md p-6 mb-8 text-white">
          <h2 className="text-lg font-semibold mb-2">Prochain rendez-vous</h2>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-2xl font-bold mb-1">{nextAppointment.clientName}</p>
              <p className="text-white text-opacity-90">{nextAppointment.service}</p>
            </div>
            <div className="mt-4 md:mt-0">
              <p className="text-xl font-bold">
                {format(parseISO(nextAppointment.date), 'd MMMM yyyy', { locale: fr })}
              </p>
              <p className="text-white text-opacity-90">
                {format(parseISO(nextAppointment.date), 'HH:mm', { locale: fr })}
              </p>
            </div>
          </div>
        </div>
      )}
      
      <SMSNotification />
      
      <div className="mb-6">
        <div className="border-b border-gray-200">
          <nav className="-mb-px flex space-x-8">
            <button
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'upcoming'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => setActiveTab('upcoming')}
            >
              À venir
            </button>
            
            <button
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'all'
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
              onClick={() => setActiveTab('all')}
            >
              Tous les rendez-vous
            </button>
          </nav>
        </div>
      </div>
      
      <AppointmentList />
    </div>
  );
};

export default Dashboard;