import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Appointment } from '../types';
import { isEqual, parseISO } from 'date-fns';

interface AppointmentState {
  appointments: Appointment[];
  addAppointment: (appointment: Omit<Appointment, 'id'>) => string | null;
  updateAppointment: (id: string, appointment: Partial<Appointment>) => void;
  cancelAppointment: (id: string) => void;
  deleteAllAppointments: () => void;
  hasTimeConflict: (date: string, duration: number, excludeId?: string) => boolean;
}

const useAppointmentStore = create<AppointmentState>()(
  persist(
    (set, get) => ({
      appointments: [],
      
      addAppointment: (appointmentData) => {
        const { date } = appointmentData;
        
        // Check for time conflicts (60 minutes duration by default)
        if (get().hasTimeConflict(date, 60)) {
          return null; // Conflict detected
        }
        
        const id = crypto.randomUUID();
        const newAppointment: Appointment = {
          ...appointmentData,
          id,
        };
        
        set((state) => ({
          appointments: [...state.appointments, newAppointment],
        }));
        
        return id;
      },
      
      updateAppointment: (id, updatedData) => {
        const { appointments } = get();
        const appointment = appointments.find(a => a.id === id);
        
        if (!appointment) return;
        
        // If date is being updated, check for conflicts
        if (updatedData.date && updatedData.date !== appointment.date) {
          if (get().hasTimeConflict(updatedData.date, 60, id)) {
            return; // Conflict detected
          }
        }
        
        set((state) => ({
          appointments: state.appointments.map((a) =>
            a.id === id ? { ...a, ...updatedData } : a
          ),
        }));
      },
      
      cancelAppointment: (id) => {
        set((state) => ({
          appointments: state.appointments.map((a) =>
            a.id === id ? { ...a, status: 'cancelled' } : a
          ),
        }));
      },
      
      deleteAllAppointments: () => {
        set({ appointments: [] });
      },
      
      hasTimeConflict: (date, duration, excludeId) => {
        const newAppointmentDate = parseISO(date);
        const newAppointmentEnd = new Date(newAppointmentDate.getTime() + duration * 60000);
        
        return get().appointments.some((existing) => {
          // Skip the appointment being updated
          if (excludeId && existing.id === excludeId) return false;
          
          // Skip cancelled appointments
          if (existing.status === 'cancelled') return false;
          
          const existingDate = parseISO(existing.date);
          const existingEnd = new Date(existingDate.getTime() + duration * 60000);
          
          // Check if the new appointment overlaps with an existing one
          return (
            (newAppointmentDate >= existingDate && newAppointmentDate < existingEnd) ||
            (newAppointmentEnd > existingDate && newAppointmentEnd <= existingEnd) ||
            (newAppointmentDate <= existingDate && newAppointmentEnd >= existingEnd)
          );
        });
      },
    }),
    {
      name: 'appointment-storage',
    }
  )
);

export default useAppointmentStore;