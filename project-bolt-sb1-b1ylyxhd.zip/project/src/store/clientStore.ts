import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Client } from '../types';

interface ClientState {
  clients: Client[];
  addClient: (client: Omit<Client, 'id'>) => string;
  updateClient: (id: string, client: Partial<Client>) => void;
  deleteClient: (id: string) => void;
  getClient: (id: string) => Client | undefined;
}

const useClientStore = create<ClientState>()(
  persist(
    (set, get) => ({
      clients: [],
      
      addClient: (clientData) => {
        const id = crypto.randomUUID();
        const newClient: Client = {
          ...clientData,
          id,
        };
        
        set((state) => ({
          clients: [...state.clients, newClient],
        }));
        
        return id;
      },
      
      updateClient: (id, updatedData) => {
        set((state) => ({
          clients: state.clients.map((c) =>
            c.id === id ? { ...c, ...updatedData } : c
          ),
        }));
      },
      
      deleteClient: (id) => {
        set((state) => ({
          clients: state.clients.filter((c) => c.id !== id),
        }));
      },
      
      getClient: (id) => {
        return get().clients.find((c) => c.id === id);
      },
    }),
    {
      name: 'client-storage',
    }
  )
);

export default useClientStore;