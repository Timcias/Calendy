import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Config } from '../types';

interface ConfigState extends Config {
  updateConfig: (config: Partial<Config>) => void;
}

const useConfigStore = create<ConfigState>()(
  persist(
    (set) => ({
      defaultInterval: 60, // 60 minutes by default
      
      updateConfig: (config) => {
        set((state) => ({
          ...state,
          ...config,
        }));
      },
    }),
    {
      name: 'config-storage',
    }
  )
);

export default useConfigStore;