export interface User {
  id: string;
  email: string;
}

export interface Client {
  id: string;
  name: string;
  phone: string;
  interval: number; // interval between appointments in minutes
}

export interface Appointment {
  id: string;
  clientId: string;
  clientName: string;
  clientPhone: string;
  service: string;
  date: string; // ISO string
  status: 'scheduled' | 'completed' | 'cancelled';
  userId: string;
}

export interface Config {
  defaultInterval: number; // default interval between appointments in minutes
}